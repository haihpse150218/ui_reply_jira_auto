// API client for interacting with the Python Lambda backend

interface CreateReplyPayload {
  message: string
  jiraIssueId: string
  phase: string
}

interface UpdateReplyPayload {
  id: string
  message?: string
  jiraIssueId?: string
  phase?: string
}

// Replace these API endpoints with your actual Lambda API endpoints
const API_BASE_URL = "/api"

export const apiClient = {
  // Get all replies
  async getReplies() {
    try {
      const response = await fetch(`${API_BASE_URL}/replies`)
      if (!response.ok) {
        throw new Error(`API error: ${response.status}`)
      }
      return await response.json()
    } catch (error) {
      console.error("Error fetching replies:", error)
      throw error
    }
  },

  // Create a new reply
  async createReply(data: CreateReplyPayload) {
    try {
      const response = await fetch(`${API_BASE_URL}/replies`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      })
      if (!response.ok) {
        throw new Error(`API error: ${response.status}`)
      }
      return await response.json()
    } catch (error) {
      console.error("Error creating reply:", error)
      throw error
    }
  },

  // Update an existing reply
  async updateReply(data: UpdateReplyPayload) {
    try {
      const response = await fetch(`${API_BASE_URL}/replies/${data.id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      })
      if (!response.ok) {
        throw new Error(`API error: ${response.status}`)
      }
      return await response.json()
    } catch (error) {
      console.error("Error updating reply:", error)
      throw error
    }
  },

  // Delete a reply
  async deleteReply(id: string) {
    try {
      const response = await fetch(`${API_BASE_URL}/replies/${id}`, {
        method: "DELETE",
      })
      if (!response.ok) {
        throw new Error(`API error: ${response.status}`)
      }
      return await response.json()
    } catch (error) {
      console.error("Error deleting reply:", error)
      throw error
    }
  },

  // Auto-reply to a single Jira issue
  async autoReplyJira(id: string) {
    try {
      const response = await fetch(`${API_BASE_URL}/replies/${id}/auto-reply`, {
        method: "POST",
      })
      if (!response.ok) {
        throw new Error(`API error: ${response.status}`)
      }
      return await response.json()
    } catch (error) {
      console.error("Error auto-replying to Jira:", error)
      throw error
    }
  },

  // Auto-reply to all Jira issues
  async autoReplyAllJira() {
    try {
      const response = await fetch(`${API_BASE_URL}/replies/auto-reply-all`, {
        method: "POST",
      })
      if (!response.ok) {
        throw new Error(`API error: ${response.status}`)
      }
      return await response.json()
    } catch (error) {
      console.error("Error auto-replying to all Jira issues:", error)
      throw error
    }
  },
}
